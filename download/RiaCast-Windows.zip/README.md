# RiaCast Windows (WebView2)

Cangkang desktop Windows untuk RiaCast. Aplikasi memuat UI dari GitHub Pages:
https://riacaya.github.io/RiaCast/

## Cara pakai
1. Ekstrak zip ini.
2. Jalankan `setup.exe` untuk memasang ke PC, atau jalankan `RiaCast.exe` langsung.
3. Runtime Microsoft Edge WebView2 harus tersedia di Windows (biasanya sudah ada di Windows 10/11).

## Catatan
- Profil WebView2: `%LOCALAPPDATA%\RiaCast\WebView2`
- Log: `%LOCALAPPDATA%\RiaCast\riacast-shell.log`
- App tidak berjalan di background; menutup jendela akan keluar dari aplikasi.
